def all_night() :
    print('sleep')
    return True