def all_day() :
    print('work')
    return True